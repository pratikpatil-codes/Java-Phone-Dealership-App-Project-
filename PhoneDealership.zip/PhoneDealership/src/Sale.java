// Yeh line 'src' package ko define kar rahi hai
package src;

// 'java.time.LocalDate' ko import kar rahe hain taaki sale ki date store kar sakein
import java.time.LocalDate;

// 'Sale' naam ki ek public class bana rahe hain
public class Sale {

    // Instance variable: Konsa model bika
    private String modelSold;
    // Instance variable: Kitni quantity biki
    private int quantitySold;
    // Instance variable: Total kitne paise bane uss sale se
    private double totalPrice;
    // Instance variable: Kis tareekh ko sale hui
    private LocalDate dateOfSale;

    // 'Sale' class ka constructor
    public Sale(String modelSold, int quantitySold, double totalPrice) {
        // 'this.modelSold' ko parameter 'modelSold' se set kar rahe hain
        this.modelSold = modelSold;
        // 'this.quantitySold' ko parameter 'quantitySold' se set kar rahe hain
        this.quantitySold = quantitySold;
        // 'this.totalPrice' ko parameter 'totalPrice' se set kar rahe hain
        this.totalPrice = totalPrice;
        // 'this.dateOfSale' ko aaj ki current date se set kar rahe hain
        this.dateOfSale = LocalDate.now();
    }

    // Yeh ek private constructor hai (hum isse file loading ke liye use karenge)
    // Yeh constructor date ko parameter ke taur par leta hai
    private Sale(String modelSold, int quantitySold, double totalPrice, LocalDate dateOfSale) {
        // 'this.modelSold' ko parameter 'modelSold' se set kar rahe hain
        this.modelSold = modelSold;
        // 'this.quantitySold' ko parameter 'quantitySold' se set kar rahe hain
        this.quantitySold = quantitySold;
        // 'this.totalPrice' ko parameter 'totalPrice' se set kar rahe hain
        this.totalPrice = totalPrice;
        // 'this.dateOfSale' ko parameter 'dateOfSale' se set kar rahe hain
        this.dateOfSale = dateOfSale;
    }


    // Yeh method sale object ko CSV format string mein convert karega file mein save karne ke liye
    public String toCsvString() {
        // Model, Quantity, Price, aur Date ko ';' se jodkar string bana rahe hain
        return modelSold + ";" + quantitySold + ";" + totalPrice + ";" + dateOfSale.toString();
    }

    // Yeh ek static method hai (class ke naam se call hota hai)
    // Yeh CSV string ko 'Sale' object mein convert karta hai (file loading ke liye)
    public static Sale fromCsvString(String csv) {
        // Line ko ';' se todo
        String[] parts = csv.split(";");
        // 'parts' array se data nikalo
        String model = parts[0]; // Pehla part model
        int quantity = Integer.parseInt(parts[1]); // Doosra part quantity
        double price = Double.parseDouble(parts[2]); // Teesra part price
        LocalDate date = LocalDate.parse(parts[3]); // Chautha part date (String se LocalDate mein convert kiya)
        // Private constructor ka istemal karke naya 'Sale' object banao aur return karo
        return new Sale(model, quantity, price, date);
    }

    // 'toString' method ko override kar rahe hain taaki sale ko achhe se display kar sakein
    @Override
    public String toString() {
        // Ek readable format mein string return kar rahe hain
        return "Date: " + dateOfSale + ", Model: " + modelSold + ", Qty: " + quantitySold + ", Total: $" + totalPrice;
    }
}