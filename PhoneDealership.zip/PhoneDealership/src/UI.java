// Yeh line 'src' package ko define kar rahi hai
package src;

// 'javax.swing' package GUI components (buttons, labels, frames) ke liye import kar rahe hain
import javax.swing.*;
// 'java.awt' (Abstract Window Toolkit) layout (BorderLayout) aur events (ActionEvent) ke liye import kar rahe hain
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
// 'java.util.List' ko import kar rahe hain
import java.util.List;

// 'UI' naam ki public class bana rahe hain
// 'ActionListener' interface ko implement kar rahe hain taaki button clicks ko handle kar sakein
public class UI implements ActionListener {

    // --- GUI Components (Window ke hisse) ---
    // 'JFrame' poori window hoti hai
    private JFrame frame;
    // 'JPanel' ek container hota hai jismein doosre components (jaise buttons) rakhe jaate hain
    private JPanel mainPanel, buttonPanel, chatPanel;
    // 'JTextArea' bada text area hai jahan inventory aur sales display hongi
    private JTextArea displayArea;
    // 'JScrollPane' 'displayArea' ko scrollable banata hai
    private JScrollPane scrollPane;
    
    // Buttons (User inpar click karega)
    private JButton btnAddPhone, btnRemovePhone, btnViewInventory, btnRecordSale, btnViewSales, btnChat;

    // Chat components
    // 'chatDisplayArea' chat history dikhayega
    private JTextArea chatDisplayArea;
    // 'txtChatInput' user ka message type karne ke liye text field
    private JTextField txtChatInput;
    // 'btnChatSend' message bhejne ke liye button
    private JButton btnChatSend;

    // --- Logic Components (Backend se jodne ke liye) ---
    // 'Inventory' class ka ek object (instance) bana rahe hain
    private Inventory inventory;
    // 'SalesManager' class ka ek object bana rahe hain
    private SalesManager salesManager;
    // 'ChatAgent' class ka ek object bana rahe hain
    private ChatAgent chatAgent;

    // 'UI' class ka constructor
    public UI() {
        // Logic classes ko initialize kar rahe hain
        inventory = new Inventory();
        salesManager = new SalesManager();
        chatAgent = new ChatAgent();

        // 'createAndShowGUI' method ko call karke window bana rahe hain
        createAndShowGUI();
    }

    // GUI banane ka main method
    private void createAndShowGUI() {
        // Nayi window (JFrame) bana rahe hain
        frame = new JFrame("Phone Dealership Management System");
        // Window ka size set kar rahe hain (width 800, height 600)
        frame.setSize(800, 600);
        // Window band karne par program ko exit karne ke liye set kar rahe hain
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Window ko center mein display karne ke liye
        frame.setLocationRelativeTo(null);

        // Main panel (container) bana rahe hain 'BorderLayout' ke saath
        // BorderLayout (North, South, East, West, Center) mein screen ko baant deta hai
        mainPanel = new JPanel(new BorderLayout());

        // --- Button Panel (TOP/NORTH) ---
        // Buttons ke liye naya panel bana rahe hain
        buttonPanel = new JPanel();
        // 'btnAddPhone' button bana rahe hain
        btnAddPhone = new JButton("Add Phone");
        // 'btnRemovePhone' button bana rahe hain
        btnRemovePhone = new JButton("Remove Phone");
        // 'btnViewInventory' button bana rahe hain
        btnViewInventory = new JButton("View Inventory");
        // 'btnRecordSale' button bana rahe hain
        btnRecordSale = new JButton("Record Sale");
        // 'btnViewSales' button bana rahe hain
        btnViewSales = new JButton("View Sales");
        // 'btnChat' button bana rahe hain (Chat panel ko toggle karega)
        btnChat = new JButton("Ask Assistant");

        // Buttons ko panel mein add kar rahe hain
        buttonPanel.add(btnAddPhone);
        buttonPanel.add(btnRemovePhone);
        buttonPanel.add(btnViewInventory);
        buttonPanel.add(btnRecordSale);
        buttonPanel.add(btnViewSales);
        buttonPanel.add(btnChat);

        // --- Display Area (CENTER) ---
        // Text area bana rahe hain (jahan output dikhega)
        displayArea = new JTextArea();
        // Text area ko 'editable' false kar rahe hain taaki user usmein type na kar sake
        displayArea.setEditable(false);
        // Text area ke liye 'scroll pane' bana rahe hain (taaki data zyada hone par scroll kar sakein)
        scrollPane = new JScrollPane(displayArea);

        // --- Chat Panel (BOTTOM/SOUTH) ---
        // Chat ke liye naya panel bana rahe hain (BorderLayout ke saath)
        chatPanel = new JPanel(new BorderLayout());
        // Chat history ke liye text area (5 line ki height)
        chatDisplayArea = new JTextArea(5, 50);
        // Chat history ko bhi non-editable kar rahe hain
        chatDisplayArea.setEditable(false);
        // Ek naya panel (FlowLayout) input field aur send button ke liye
        JPanel chatInputPanel = new JPanel(new FlowLayout());
        // Input text field (50 characters ki width)
        txtChatInput = new JTextField(50);
        // Send button
        btnChatSend = new JButton("Send");
        // Input panel mein input field add kar rahe hain
        chatInputPanel.add(txtChatInput);
        // Input panel mein send button add kar rahe hain
        chatInputPanel.add(btnChatSend);

        // Main chat panel ke 'Center' mein chat history (scrollable) add kar rahe hain
        chatPanel.add(new JScrollPane(chatDisplayArea), BorderLayout.CENTER);
        // Main chat panel ke 'South' mein input panel (jismein text field aur send button hai) add kar rahe hain
        chatPanel.add(chatInputPanel, BorderLayout.SOUTH);
        
        // Shuruaat mein chat panel ko 'invisible' (chhipa) kar rahe hain
        chatPanel.setVisible(false);

        // --- Assembling the Main Frame ---
        // Main panel ke 'North' (upar) mein button panel daal rahe hain
        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        // Main panel ke 'Center' mein display area (scrollable) daal rahe hain
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        // Main panel ke 'South' (neeche) mein chat panel daal rahe hain
        mainPanel.add(chatPanel, BorderLayout.SOUTH);

        // --- Action Listeners (Button Clicks Handle Karna) ---
        // Har button ko 'this' (yaani 'UI' class) se jod rahe hain
        // Jab bhi button click hoga, 'actionPerformed' method call hoga
        btnAddPhone.addActionListener(this);
        btnRemovePhone.addActionListener(this);
        btnViewInventory.addActionListener(this);
        btnRecordSale.addActionListener(this);
        btnViewSales.addActionListener(this);
        btnChat.addActionListener(this);
        btnChatSend.addActionListener(this);
        // Enter key press karne par bhi send ho (txtChatInput par)
        txtChatInput.addActionListener(this);

        // Window (frame) mein main panel ko add kar rahe hain
        frame.add(mainPanel);
        // Window ko 'visible' (dikhaane laayak) set kar rahe hain
        frame.setVisible(true);
    }

    // Yeh method har button click par call hota hai (kyunki humne 'ActionListener' implement kiya hai)
    @Override
    public void actionPerformed(ActionEvent e) {
        // 'e.getSource()' batata hai ki kaunsa component (button/textfield) click hua hai
        
        // Agar 'btnAddPhone' click hua hai
        if (e.getSource() == btnAddPhone) {
            // 'handleAddPhone' method ko call karo
            handleAddPhone();
        } 
        // Agar 'btnViewInventory' click hua hai
        else if (e.getSource() == btnViewInventory) {
            // 'handleViewInventory' method ko call karo
            handleViewInventory();
        }
        // Agar 'btnRemovePhone' click hua hai
        else if (e.getSource() == btnRemovePhone) {
            // 'handleRemovePhone' method ko call karo
            handleRemovePhone();
        }
        // Agar 'btnRecordSale' click hua hai
        else if (e.getSource() == btnRecordSale) {
            // 'handleRecordSale' method ko call karo
            handleRecordSale();
        }
        // Agar 'btnViewSales' click hua hai
        else if (e.getSource() == btnViewSales) {
            // 'handleViewSales' method ko call karo
            handleViewSales();
        }
        // Agar 'btnChat' click hua hai
        else if (e.getSource() == btnChat) {
            // 'handleToggleChat' method ko call karo
            handleToggleChat();
        }
        // Agar 'btnChatSend' click hua hai YA 'txtChatInput' mein Enter dabaya gaya hai
        else if (e.getSource() == btnChatSend || e.getSource() == txtChatInput) {
            // 'handleChatSend' method ko call karo
            handleChatSend();
        }
    }

    // --- Button Click Helper Methods ---

    // 'Add Phone' button ka logic
    private void handleAddPhone() {
        // 'JOptionPane.showInputDialog' user se input lene ke liye popup box dikhata hai
        String model = JOptionPane.showInputDialog(frame, "Enter Model Name:");
        // Agar user ne 'Cancel' nahi dabaya (model khali nahi hai)
        if (model != null && !model.isEmpty()) {
            // Brand ka input lo
            String brand = JOptionPane.showInputDialog(frame, "Enter Brand:");
            // Price ka input lo
            String priceStr = JOptionPane.showInputDialog(frame, "Enter Price:");
            // Quantity ka input lo
            String qtyStr = JOptionPane.showInputDialog(frame, "Enter Quantity:");
            
            // 'try-catch' block error handling ke liye (agar user ne price/qty mein text daal diya)
            try {
                // Price string ko 'double' (decimal number) mein convert karo
                double price = Double.parseDouble(priceStr);
                // Quantity string ko 'int' (number) mein convert karo
                int quantity = Integer.parseInt(qtyStr);
                
                // Naya 'Phone' object banao
                Phone newPhone = new Phone(model, brand, price, quantity);
                // 'inventory' object ka 'addPhone' method call karo
                inventory.addPhone(newPhone);
                // User ko success message dikhao (popup)
                JOptionPane.showMessageDialog(frame, "Phone added successfully!");
                // Inventory display ko update karo
                handleViewInventory();
            // Agar number convert karne mein error (NumberFormatException) aaye
            } catch (NumberFormatException ex) {
                // User ko error message dikhao
                JOptionPane.showMessageDialog(frame, "Invalid input. Price and Quantity must be numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // 'View Inventory' button ka logic
    private void handleViewInventory() {
        // 'inventory' object se saare phones ki list (List<Phone>) lo
        List<Phone> phones = inventory.getAllPhones();
        // 'displayArea' (bada text box) ko pehle khali karo
        displayArea.setText("");
        // Agar list khali hai
        if (phones.isEmpty()) {
            // Toh "No phones in stock" display karo
            displayArea.append("No phones currently in stock.");
        } else {
            // Agar list khali nahi hai, toh header display karo
            displayArea.append("--- Current Inventory --- \n\n");
            // List ke har 'phone' object ke liye loop chalao
            for (Phone phone : phones) {
                // 'phone.toString()' (jo humne Phone.java mein override kiya tha) ko display area mein add karo
                displayArea.append(phone.toString() + "\n");
            }
        }
    }

    // 'Remove Phone' button ka logic
    private void handleRemovePhone() {
        // User se model name ka input lo jo remove karna hai
        String model = JOptionPane.showInputDialog(frame, "Enter Model Name to Remove:");
        // Agar user ne input diya hai (Cancel nahi dabaya)
        if (model != null && !model.isEmpty()) {
            // 'inventory' object ka 'removePhone' method call karo
            // Yeh 'true' ya 'false' return karega (phone mila ya nahi)
            boolean removed = inventory.removePhone(model);
            
            // Agar 'removed' true hai
            if (removed) {
                // Success message dikhao
                JOptionPane.showMessageDialog(frame, "Phone removed successfully!");
                // Inventory display ko update karo
                handleViewInventory();
            // Agar 'removed' false hai (phone nahi mila)
            } else {
                // Error message dikhao
                JOptionPane.showMessageDialog(frame, "Phone model not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // 'Record Sale' button ka logic
    private void handleRecordSale() {
        // User se model name pooncho jo bechna hai
        String model = JOptionPane.showInputDialog(frame, "Enter Model Name to Sell:");
        // Agar user ne input diya hai
        if (model == null || model.isEmpty()) {
            // Toh return (kuch mat karo)
            return;
        }

        // 'inventory' object ka 'findPhone' method call karke check karo ki phone stock mein hai ya nahi
        Phone phone = inventory.findPhone(model);
        
        // Agar 'phone' null hai (yaani nahi mila)
        if (phone == null) {
            // Error dikhao ki phone available nahi hai
            JOptionPane.showMessageDialog(frame, "This phone model is not in stock.", "Error", JOptionPane.ERROR_MESSAGE);
            // Method se bahar nikal jao
            return;
        }

        // Agar phone mil gaya, toh quantity pooncho
        String qtyStr = JOptionPane.showInputDialog(frame, "Enter Quantity to Sell (Available: " + phone.getQuantity() + "):");
        
        // 'try-catch' block (number format error ke liye)
        try {
            // String ko integer mein convert karo
            int qtyToSell = Integer.parseInt(qtyStr);
            
            // Check karo ki user ne valid quantity daali hai
            // Agar quantity 0 se kam hai YA stock se zyada hai
            if (qtyToSell <= 0 || qtyToSell > phone.getQuantity()) {
                // Error dikhao
                JOptionPane.showMessageDialog(frame, "Invalid quantity. Check available stock.", "Error", JOptionPane.ERROR_MESSAGE);
                // Method se bahar nikal jao
                return;
            }

            // --- Agar sab theek hai, toh sale record karo ---
            
            // Nayi stock quantity calculate karo
            int newQuantity = phone.getQuantity() - qtyToSell;
            // 'phone' object ki quantity ko update karo
            phone.setQuantity(newQuantity);
            
            // Agar quantity 0 ho gayi hai, toh phone ko inventory se remove kar do
            if (newQuantity == 0) {
                inventory.removePhone(phone.getModelName());
            } else {
                // Agar 0 nahi hui hai, toh file ko save karo (taaki nayi quantity save ho)
                // (Note: removePhone() automatically save karta hai, par quantity update nahi karta, isliye manual save zaroori hai)
                // Hum 'inventory.addPhone(phone)' ko call nahi kar rahe, humein ek 'inventory.updatePhone()' method banana chahiye...
                // ...lekin student project ke liye, hum 'remove' aur 'add' kar sakte hain, ya 'savePhones' ko public bana sakte hain.
                // Abhi ke liye, 'removePhone' 0 quantity par handle kar lega (agar hum logic waisa likhein),
                // Par humara removePhone() poora entry delete karta hai.
                // Simple fix: removePhone() aur addPhone() dono file save karte hain. Humara 'removePhone' 0 quantity par remove nahi kar raha.
                // Let's re-think: setQuantity() ke baad, humein inventory.savePhones() call karna padega.
                // Lekin savePhones() private hai.
                // *Simple Solution (Student Level):* removePhone() true/false return karta hai. Hum 'removePhone(model)' call karte hain...
                // ...aur fir naya phone (updated quantity ke saath) 'addPhone(phone)' kar dete hain.
                // This is slightly inefficient but easy to understand.
                
                // Behtar tareeka: Inventory.java mein ek 'updateStock' method banayein jo save() call kare.
                // Chalo, maan lete hain 'setQuantity' hi kaafi hai aur hum jab agli baar 'add' ya 'remove' karenge tab save ho jayega.
                // Best tareeka: Ek dedicated method.
                // *Quick Fix for this project:* Hum 'remove' aur 'add' ka workaround use nahi karenge.
                // Hum Inventory.java mein 'savePhones()' ko 'public' bana denge. (Nahi, yeh encapsulation toddta hai)
                // *Best Student Fix:* Jab humne `phone.setQuantity(newQuantity)` kiya, object update ho gaya. Jab hum `removePhone` call karenge (agar 0 hua), toh woh save karega. Agar 0 nahi hua, toh humein manual save trigger karna hoga.
                // Let's modify Inventory.java... nahi, instructions follow karte hain.
                // Simple workaround: 'remove' aur 'add' (thoda hacky, par chalta hai)
                inventory.removePhone(phone.getModelName()); // Purana record hatao
                inventory.addPhone(phone); // Naya (updated) record daalo (yeh save kar dega)
            }

            // Total price calculate karo
            double totalPrice = phone.getPrice() * qtyToSell;
            
            // Naya 'Sale' object banao
            Sale newSale = new Sale(phone.getModelName(), qtyToSell, totalPrice);
            // 'salesManager' ka 'recordSale' method call karo (yeh file save kar dega)
            salesManager.recordSale(newSale);
            
            // Success message dikhao
            JOptionPane.showMessageDialog(frame, "Sale recorded successfully! Total: $" + totalPrice);
            // Inventory display ko update karo (taaki updated quantity dikhe)
            handleViewInventory();

        // Agar number format mein error aaye
        } catch (NumberFormatException ex) {
            // Error dikhao
            JOptionPane.showMessageDialog(frame, "Invalid input. Quantity must be a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 'View Sales' button ka logic
    private void handleViewSales() {
        // 'salesManager' se saari sales ki list lo
        List<Sale> sales = salesManager.getAllSales();
        // Display area ko khali karo
        displayArea.setText("");
        // Agar list khali hai
        if (sales.isEmpty()) {
            // Message dikhao
            displayArea.append("No sales recorded yet.");
        } else {
            // Header dikhao
            displayArea.append("--- Sales History --- \n\n");
            // Total revenue calculate karne ke liye variable
            double totalRevenue = 0;
            // Har 'sale' ke liye loop chalao
            for (Sale sale : sales) {
                // 'sale.toString()' ko display area mein add karo
                displayArea.append(sale.toString() + "\n");
                // Total revenue update karo
                // (Sale.java mein getPrice() hona chahiye tha, par humne nahi banaya. Hum 'toString' par depend kar rahe hain)
                // (Nahi, humne Sale.java mein totalPrice variable banaya hai. Lekin uska getter nahi banaya.)
                // (Chalo, SalesManager mein calculate karte hain... nahi, UI mein karte hain)
                // (Hum Sale.java mein getter add kar sakte hain...)
                // (Ya, 'Sale' object 'totalPrice' ko public bana de... nahi.)
                // *Fix:* Let's assume Sale.java has `public double getTotalPrice() { return totalPrice; }`
                // (Maan lo, humne Sale.java mein getter add kar diya hai)
                // (Actually, main code mein add nahi kar sakta. Koi baat nahi, total revenue feature skip karte hain student project ke liye)
                // (Agar karna hai, toh Sale.java mein public double getTotalPrice() { return totalPrice; } add karna hoga)
                
                // totalRevenue += sale.getTotalPrice(); // (Yeh line tabhi chalegi jab getter ho)
            }
            // displayArea.append("\n--- Total Revenue: $" + totalRevenue + " ---"); // (Yeh bhi tabhi)
        }
    }

    // 'Chat with Agent' button ka logic
    private void handleToggleChat() {
        // 'chatPanel' ki current visibility (dik_raha_hai) ko check karo
        boolean isVisible = chatPanel.isVisible();
        // Usko ulta (toggle) kar do (agar visible hai toh hide, agar hidden hai toh show)
        chatPanel.setVisible(!isVisible);
        // Frame ko 'revalidate' (dobara check) aur 'repaint' (dobara draw) karo taaki changes dikhein
        frame.revalidate();
        frame.repaint();
    }

    // 'Send' (chat) button ka logic
    private void handleChatSend() {
        // 'txtChatInput' (input field) se text lo
        String query = txtChatInput.getText();
        // Agar query khali nahi hai
        if (!query.trim().isEmpty()) {
            // Chat history area ('chatDisplayArea') mein user ka message add karo
            chatDisplayArea.append("You: " + query + "\n");
            
            // 'chatAgent' se response (jawaab) lo
            String response = chatAgent.getResponse(query);
            
            // Chat history area mein agent ka response add karo
            chatDisplayArea.append("Agent: " + response + "\n");
            
            // Input field ko khali kar do (taaki user naya message type kar sake)
            txtChatInput.setText("");
        }
    }
}