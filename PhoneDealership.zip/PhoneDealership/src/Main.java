// Yeh line 'src' package ko define kar rahi hai
package src;

// 'javax.swing.SwingUtilities' ko import kar rahe hain
// Yeh Swing applications ko thread-safe tareeke se run karne mein help karta hai
import javax.swing.SwingUtilities;

// 'Main' naam ki public class bana rahe hain
public class Main {

    // Yeh 'main' method hai, Java program ka entry point (shuruaat yahan se hoti hai)
    // 'public static void' standard Java syntax hai
    public static void main(String[] args) {
        
        // 'SwingUtilities.invokeLater' ka use kar rahe hain
        // Yeh best practice hai: GUI ko hamesha 'Event Dispatch Thread' (EDT) par create karna chahiye
        // '() -> new UI()' ek Lambda expression hai jo 'Runnable' interface ko implement kar raha hai
        // Aasan bhasha mein: "Java, please yeh kaam (new UI()) tab karna jab tum GUI related kaam karne ke liye ready ho"
        SwingUtilities.invokeLater(() -> {
            // 'UI' class ka naya object (instance) bana rahe hain
            // Jab 'new UI()' call hoga, toh UI.java ka constructor run hoga aur window ban jayegi
            new UI();
        });
    }
}