// Yeh line 'java.io' package ko import kar rahi hai taaki hum 'Serializable' use kar sakein (future-proofing, although hum text file use kar rahe)
package src;

// Humne 'Phone' naam ki ek public class banayi hai
public class Phone {

    // Instance variable: Phone ka model name store karega (jaise "iPhone 15")
    private String modelName;
    // Instance variable: Phone ka brand store karega (jaise "Apple")
    private String brand;
    // Instance variable: Phone ki keemat store karega (jaise 799.99)
    private double price;
    // Instance variable: Stock mein kitne phone hain, woh store karega
    private int quantity;

    // Yeh 'Phone' class ka constructor hai
    // Jab bhi 'new Phone(...)' call hoga, yeh run hoga
    public Phone(String modelName, String brand, double price, int quantity) {
        // 'this.modelName' (class ka variable) ko parameter 'modelName' (jo bahar se aaya) assign kar rahe hain
        this.modelName = modelName;
        // 'this.brand' ko parameter 'brand' assign kar rahe hain
        this.brand = brand;
        // 'this.price' ko parameter 'price' assign kar rahe hain
        this.price = price;
        // 'this.quantity' ko parameter 'quantity' assign kar rahe hain
        this.quantity = quantity;
    }

    // --- Getter Methods (Variables ki value return karne ke liye) ---

    // Yeh method phone ka model name return karega
    public String getModelName() {
        // 'modelName' ki value ko return kar rahe hain
        return modelName;
    }

    // Yeh method phone ka brand return karega
    public String getBrand() {
        // 'brand' ki value ko return kar rahe hain
        return brand;
    }

    // Yeh method phone ki price return karega
    public double getPrice() {
        // 'price' ki value ko return kar rahe hain
        return price;
    }

    // Yeh method phone ki quantity return karega
    public int getQuantity() {
        // 'quantity' ki value ko return kar rahe hain
        return quantity;
    }

    // --- Setter Methods (Variables ki value change karne ke liye) ---

    // Yeh method phone ki quantity set karega
    public void setQuantity(int quantity) {
        // 'this.quantity' (class ka variable) ko parameter 'quantity' se update kar rahe hain
        this.quantity = quantity;
    }

    // Yeh method phone object ko file mein save karne ke liye CSV (Comma Separated) format string mein convert karega
    // Hum yahan ';' (semicolon) use kar rahe hain taaki comma wali price (e.g., 1,000.00) se problem na ho
    public String toCsvString() {
        // Model, Brand, Price, aur Quantity ko ';' se jodkar ek string bana rahe hain
        return modelName + ";" + brand + ";" + price + ";" + quantity;
    }

    // Yeh method 'toString()' ko override kar raha hai taaki hum list mein phone ko achhe se display kar sakein
    @Override
    public String toString() {
        // Ek readable format mein string return kar rahe hain
        return "Model: " + modelName + ", Brand: " + brand + ", Price: $" + price + ", Stock: " + quantity;
    }
}