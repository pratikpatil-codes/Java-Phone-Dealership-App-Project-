// Yeh line 'src' package ko define kar rahi hai
package src;

// 'ChatAgent' naam ki public class bana rahe hain
public class ChatAgent {

    // Yeh method user ke 'query' (sawaal) ka jawaab dega
    // Yeh simple rule-based logic hai
    public String getResponse(String query) {
        
        // User ke query ko chhota kar rahe hain (lowercase) taaki case-sensitivity (bade/chhote letters) ka farq na pade
        String lowerQuery = query.toLowerCase();

        // Rule 1: Agar query mein "add" aur "phone" dono shabd hain
        if (lowerQuery.contains("add") && lowerQuery.contains("phone")) {
            // Toh yeh instruction return karo
            return "To add a phone, click the 'Add Phone' button and fill in the Model, Brand, Price, and Quantity.";
        
        // Rule 2: (Else if) Agar query mein "remove" ya "delete" shabd hain
        } else if (lowerQuery.contains("remove") || lowerQuery.contains("delete")) {
            // Toh yeh instruction return karo
            return "To remove a phone, click the 'Remove Phone' button and enter the exact model name.";
        
        // Rule 3: (Else if) Agar query mein "view" ya "inventory" shabd hain
        } else if (lowerQuery.contains("view") || lowerQuery.contains("inventory")) {
            // Toh yeh instruction return karo
            return "To see all phones, click the 'View Inventory' button. The list will appear in the main text area.";
        
        // Rule 4: (Else if) Agar query mein "sale" ya "record" shabd hain
        } else if (lowerQuery.contains("sale") || lowerQuery.contains("record")) {
            // Toh yeh instruction return karo
            return "To record a sale, click 'Record Sale'. Enter the model name and quantity. The stock will update automatically.";
        
        // Rule 5: (Else if) Agar query mein "hi", "hello", ya "help" hai
        } else if (lowerQuery.contains("hi") || lowerQuery.contains("hello") || lowerQuery.contains("help")) {
            // Toh yeh greeting/help message return karo
            return "Hello! I am your help agent. How can I assist you with inventory or sales tasks?";
        
        // Default Rule (Else): Agar upar ka koi bhi rule match nahi hota
        } else {
            // Toh yeh generic response return karo
            return "Sorry, I didn’t understand that. Try asking about 'add phone', 'remove phone', 'view inventory', or 'record sale'.";
        }
    }
}