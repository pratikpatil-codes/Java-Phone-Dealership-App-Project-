// Yeh line 'src' package ko define kar rahi hai
package src;

// 'java.io' se file handling classes import kar rahe hain
import java.io.*;
// 'java.util' se 'ArrayList' aur 'List' import kar rahe hain
import java.util.ArrayList;
import java.util.List;

// 'SalesManager' naam ki public class bana rahe hain
public class SalesManager {

    // Ek 'List' (dynamic array) bana rahe hain jismein 'Sale' objects store honge
    private List<Sale> salesList;
    // File ka path jahan sales save hongi
    private String filePath = "data/sales.txt";

    // 'SalesManager' class ka constructor
    public SalesManager() {
        // 'salesList' ko ek naye 'ArrayList' ke taur par initialize (shuru) kar rahe hain
        this.salesList = new ArrayList<>();
        // 'loadSales' method ko call kar rahe hain taaki purani sales file se load ho jaayein
        loadSales();
    }

    // Nayi sale record karne ka method
    public void recordSale(Sale sale) {
        // 'salesList' (jo list hai) usmein naya 'sale' object add kar rahe hain
        salesList.add(sale);
        // 'saveSales' method ko call kar rahe hain taaki nayi sale file mein bhi save ho jaaye
        saveSales();
    }

    // Saari sales ki list return karne ka method
    public List<Sale> getAllSales() {
        // Poori 'salesList' return kar do
        return salesList;
    }

    // --- File Handling Methods ---

    // Method: File ('sales.txt') se sales load karne ke liye
    private void loadSales() {
        // 'try-with-resources' block (BufferedReader ko automatically close karega)
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Ek string variable 'line' banaya
            String line;
            // 'while' loop: jab tak 'reader.readLine()' null nahi ho jaata
            while ((line = reader.readLine()) != null) {
                // Agar line khali nahi hai
                if (!line.trim().isEmpty()) {
                    // 'Sale' class ke static 'fromCsvString' method ka use karke string ko object mein badlo
                    Sale sale = Sale.fromCsvString(line);
                    // Us 'sale' object ko 'salesList' mein add karo
                    salesList.add(sale);
                }
            }
        // Agar file nahi mili (FileNotFoundException) ya koi aur error (IOException) aaye
        } catch (IOException e) {
            // Console par error print karo
            System.out.println("Error loading sales file: " + e.getMessage());
        }
    }

    // Method: Sales ko file ('sales.txt') mein save karne ke liye
    private void saveSales() {
        // 'try-with-resources' block (BufferedWriter ko automatically close karega)
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // 'salesList' mein har 'sale' ke liye loop chalao
            for (Sale sale : salesList) {
                // Har sale ko CSV format string mein convert karo
                writer.write(sale.toCsvString());
                // 'newLine()' agli line mein jaane ke liye
                writer.newLine();
            }
        // Agar file likhte waqt koi error (IOException) aaye
        } catch (IOException e) {
            // Console par error print karo
            System.out.println("Error saving sales file: " + e.getMessage());
        }
    }
}