// Yeh line 'src' package ko define kar rahi hai
package src;

// 'java.io' se file handling (BufferedReader, BufferedWriter, etc.) ke liye classes import kar rahe hain
import java.io.*;
// 'java.util' se 'ArrayList' aur 'List' import kar rahe hain
import java.util.ArrayList;
import java.util.List;
// 'java.util.stream' se 'Collectors' import kar rahe hain (modern tareeka list filter karne ka, par hum simple use karenge)
import java.util.stream.Collectors;

// 'Inventory' naam ki public class bana rahe hain
public class Inventory {

    // Ek 'List' (dynamic array) bana rahe hain jismein 'Phone' objects store honge
    private List<Phone> phoneList;
    // File ka path (raasta) jahan phones save honge (data folder ke andar)
    private String filePath = "data/phones.txt";

    // 'Inventory' class ka constructor
    public Inventory() {
        // 'phoneList' ko ek naye 'ArrayList' ke taur par initialize (shuru) kar rahe hain
        this.phoneList = new ArrayList<>();
        // 'loadPhones' method ko call kar rahe hain taaki program start hote hi purana data file se load ho jaaye
        loadPhones();
    }

    // --- Core Inventory Methods ---

    // Naya phone inventory mein add karne ka method
    public void addPhone(Phone phone) {
        // 'phoneList' (jo list hai) usmein naya 'phone' object add kar rahe hain
        phoneList.add(phone);
        // 'savePhones' method ko call kar rahe hain taaki naya phone file mein bhi save ho jaaye
        savePhones();
    }

    // Phone ko inventory se remove karne ka method (model name se)
    public boolean removePhone(String modelName) {
        // 'phoneList' se 'removeIf' (ek condition ke basis par remove) ka istemal kar rahe hain
        // 'phone ->' ek Lambda expression hai (Java 8 feature)
        // Yeh check kar raha hai ki kya 'phone' ka 'modelName' diye gaye 'modelName' se match karta hai (case ignore karte hue)
        boolean removed = phoneList.removeIf(phone -> phone.getModelName().equalsIgnoreCase(modelName));
        // Agar phone successfully remove hua hai (removed == true)
        if (removed) {
            // Toh file ko naye (updated) data ke saath save karo
            savePhones();
        }
        // Return karo ki phone remove hua ya nahi (true ya false)
        return removed;
    }

    // Model name se phone search karne ka method (yeh optional hai par helpful hai)
    public Phone findPhone(String modelName) {
        // 'phoneList' mein loop (iteration) chala rahe hain
        for (Phone phone : phoneList) {
            // Agar list ke kisi 'phone' ka 'modelName' diye gaye 'modelName' se match karta hai
            if (phone.getModelName().equalsIgnoreCase(modelName)) {
                // Toh us 'phone' object ko return kar do
                return phone;
            }
        }
        // Agar loop khatm ho gaya aur phone nahi mila, toh 'null' (kuch nahi) return karo
        return null;
    }

    // Saare phones ki list return karne ka method
    public List<Phone> getAllPhones() {
        // Poori 'phoneList' return kar do
        return phoneList;
    }

    // --- File Handling Methods ---

    // Method: File ('phones.txt') se phones load karne ke liye
    private void loadPhones() {
        // 'try-with-resources' block (yeh automatically file reader ko band kar deta hai, error aaye ya na aaye)
        // 'BufferedReader' file ko line-by-line padhne mein expert hai
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Ek string variable 'line' banaya
            String line;
            // 'while' loop: jab tak 'reader.readLine()' null (khali) nahi ho jaata, tab tak chalo
            // 'reader.readLine()' file ki agli line padhta hai
            while ((line = reader.readLine()) != null) {
                // Agar line khali nahi hai
                if (!line.trim().isEmpty()) {
                    // Line ko ';' (semicolon) se todo (split karo)
                    String[] parts = line.split(";");
                    // 'parts' array se data nikalo
                    String model = parts[0]; // Pehla hissa model hai
                    String brand = parts[1]; // Doosra hissa brand hai
                    double price = Double.parseDouble(parts[2]); // Teesra hissa price hai (String se double mein convert kiya)
                    int quantity = Integer.parseInt(parts[3]); // Chautha hissa quantity hai (String se integer mein convert kiya)
                    // Naya 'Phone' object banao
                    Phone phone = new Phone(model, brand, price, quantity);
                    // Us phone ko 'phoneList' mein add karo (bina save kiye, kyunki hum load kar rahe hain)
                    phoneList.add(phone);
                }
            }
        // Agar file nahi mili (FileNotFoundException) ya koi aur error (IOException) aaye
        } catch (IOException e) {
            // Console par error print karo (student project ke liye theek hai)
            System.out.println("Error loading phones file: " + e.getMessage());
        }
    }

    // Method: Phones ko file ('phones.txt') mein save karne ke liye
    private void savePhones() {
        // 'try-with-resources' block (BufferedWriter ko automatically close karega)
        // 'BufferedWriter' file mein data likhne ke liye efficient hai
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // 'phoneList' mein har 'phone' ke liye loop chalao
            for (Phone phone : phoneList) {
                // Har phone ko CSV format string mein convert karo (jo method humne Phone.java mein banaya tha)
                writer.write(phone.toCsvString());
                // 'newLine()' agli line mein jaane ke liye
                writer.newLine();
            }
        // Agar file likhte waqt koi error (IOException) aaye
        } catch (IOException e) {
            // Console par error print karo
            System.out.println("Error saving phones file: " + e.getMessage());
        }
    }
}